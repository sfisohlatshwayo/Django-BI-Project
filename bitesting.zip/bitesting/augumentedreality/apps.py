from django.apps import AppConfig


class AugumentedrealityConfig(AppConfig):
    name = 'augumentedreality'
