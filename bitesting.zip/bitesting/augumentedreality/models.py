from django.db import models

# Create your models here.
class augumentedreality(models.Model):
    #adNum = models.CharField(max_length=200)
    #stuffNum = models.CharField(max_length=200)
    #RevType = models.CharField(max_length=200)
    adNum= models.CharField(max_length=200)
    revenueType= models.CharField(max_length=200)
    publication= models.CharField(max_length=200)
    publishedDate= models.CharField(max_length=200)
    customerNumber= models.CharField(max_length=200)
    customer= models.CharField(max_length=200)
    salesNumber= models.CharField(max_length=200)
    adTaker= models.CharField(max_length=200)
    salesGroup= models.CharField(max_length=200)
    aRSurcharge= models.CharField(max_length=200)
    dcode = models.CharField(max_length=200)



    def __str__(self):
     return self.adNum

    class Meta:
        verbose_name_plural = "augumentedreality"
