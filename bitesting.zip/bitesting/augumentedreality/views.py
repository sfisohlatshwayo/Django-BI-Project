from django.shortcuts import render
from django.http import HttpResponse
from .models  import augumentedreality



# from ipdb import set_trace as bp
# Create your views here.
def index(request):
    #return HttpResponse('Hello from augumentedreality')
    #for ten ads
    #Augumentedreality = augumentedreality.objects.all()[:10]

    Augumentedreality = augumentedreality.objects.all()
    #print(Augumentedreality)
    context = {
    'title':'Augumented Reality Ads',
    'augumentedreality':Augumentedreality
    }
    return render(request,'augumentedreality/index.html',context)

def search_form(request):
    return render(request, 'augumentedreality/index.html')

def search(request):
    error = False
    if 'q' in request.GET:
        q = request.GET['q']
        if not q:
            error = True
        else:
            Augumentedreality = augumentedreality.objects.all()[:1]
            context = {
            'title':'Augumented Reality Ads',
            'augumentedreality':Augumentedreality
            }
            return render(request,'augumentedreality/index.html',context)
    return render(request, 'augumentedreality/index.html', {'error': error} )

'''
    if 'q' in request.GET:
        message = 'You searched for: %r' % request.GET['q']
        Augumentedreality = augumentedreality.objects.all()[:1]
        context = {
        'title':'Augumented Reality Ads',
        'augumentedreality':Augumentedreality
        }
        #message = 'You submitted hello.'
    else:
        message = 'You submitted an empty form.'
    return render(request,'augumentedreality/index.html',context)
'''
